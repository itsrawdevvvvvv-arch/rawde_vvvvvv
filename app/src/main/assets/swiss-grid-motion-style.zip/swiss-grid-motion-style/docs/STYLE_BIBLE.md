# STYLE BIBLE: "Swiss Grid Motion" (editorial motion design)
Source: 3 reference clips (18.5 s 4:3 30 fps / 21.2 s 16:9 24 fps / 6.7 s 16:9 30 fps). Look read from frames, colours quantized from them.
Motion timing is ESTIMATED from sparse stills. Fonts identified by eye. Audio: only loudness was measured (see section 8).

## 0. PRIME DIRECTIVE: EVERYTHING IS PRESENTED VISUALLY
1. **The grid is the design.** Every scene is built on visible thin guide lines, with nodes at intersections. Type, photos and blocks snap to the grid cells. If an element is not on a grid line or cell edge, move it.
2. **Every idea = one word + one image.** A beat shows ONE big condensed headline word (CREATE. / WILD. / BLOOM / STILLNESS) and ONE photo/video/cutout. No paragraphs, no bullet lists, no plain text-only scenes.
3. **Typography is a graphic object**: oversized, tight, uppercase, placed at grid intersections, sometimes inside a solid colour box, sometimes cropped by the frame or masked by the image.
4. **Micro-captions add the "designed" feel**: 2-3 lines of tiny tracked uppercase text in the cell corners (FRAME 01, REC. 03, SHOT ON 3D). They are decoration + meaning, never the main message.
5. **Reveal by masks**: lines draw on, boxes and photos wipe in, headline lines slide up from a mask. No fades-only, no bounce, no glow, no drop shadows.
6. **Restraint**: two typefaces, one red, one neutral background per scene. Never add colours, gradients, outlines, emoji.
7. Build, then LOOK at a contact sheet and fix anything that is off-grid, crowded or low-contrast.

## 1. Three looks (same system)
| look | background | lines | type | use |
|---|---|---|---|---|
| A "White grid" (ref 2) | `#FFFFFF` | solid red 3 px | red Anton headlines; white-on-red box | title cards, quote beats, calm photo beats |
| B "Grey dashed grid" (ref 1) | `#D9D9D9` | dashed red 2 px (9 px dash), red nodes | deep-red `#8B191A` Anton, small deep-red captions | studio/portfolio reels, product showcase; B/W + red duotone photo tiles; 3D cutouts in red cells |
| C "Black / red / wide" (ref 3) | `#000000`, `#CC0E30` red, `#F3F2F7` paper | dotted/thin white or red lines, white annotation boxes | wide extended sans in white or red | fast tech/botanical/product detail beats |
Mixing: switch looks with a hard cut or a full-frame colour wipe (red wipes up, black wipes across). Keep one look per 3-6 s.

## 2. Palette
white `#FFFFFF`, paper `#F3F2F7`, grey `#D9D9D9`, black `#000000`, red `#C8141C` (box/blocks on white), deep red `#8B191A` (grey look, duotone, red cells), hot red `#CC0E30` (look C field and type), light line `rgba(255,255,255,.35-.5)` on red/black.
Photo treatment: grayscale tiles in look B (some deep-red duotone), full-colour hero tile, grayscale blurred copy of the hero photo as full-frame background in look A (BLOOM beat).

## 3. Typography (free Google Fonts; put TTFs in `fonts/`)
- **Headline:** Anton (stand-ins Bebas Neue, League Gothic, Oswald Bold). UPPERCASE, line-height ~.98, no letter-spacing change. Sizes @1920: hero 150-190 px (SMART, THE SMART STUDIOS), secondary 90-100 px (CREATE. / INSPIRE.), small 70 px. Punctuation period on short words ("WILD.", "CREATE.") is part of the voice.
- **Captions:** Montserrat Regular, UPPERCASE, 20-26 px, tracking +.03em, line-height 1.22, 2-3 lines, aligned toward the nearest grid line (right-aligned text left of a line, left-aligned right of it).
- **Wide display (look C):** Unbounded Medium (stand-ins Syne, Krona One), 160-200 px, white or red; letters may be cropped by the frame or masked by a photo tile.
- **Annotation labels (look C):** Montserrat 20 px white, e.g. `Surface_01`, `Stigma`, placed above a white 2 px box with four 14 px square handles.

## 4. Layout
- Use a 3x3 or 3x4 grid: verticals at ~1/3 and ~2/3 (e.g. x = 697 and 1221 on a 1920 stage), horizontals around the vertical centre (y = 430 and 626) for title cards.
- Headline sits on a line: baseline directly above a horizontal line (CREATE. / INSPIRE.), or fills a cell as a solid red box with white text (SMART, 524x196).
- Photos fill whole cells (cells can differ in size). Photos grow from a small cell to a full-bleed cell (look A), or sit in clusters of 4-6 tiles of different sizes (look B).
- Captions live in the 4 corner cells. Keep 60 px outer margin.
- 4:3 (ref 1) and 16:9 (refs 2-3) are both used; the engine stage is 16:9 1920x1080; for 4:3 change the stage size in `components.css` and re-place elements.

## 5. Components (`style/components.css`, `engine/engine.js`)
`line` (solid or dashed, draws on), `node` (red dot/square at intersections), `rect` (red/white/black block that wipes), `tile` (photo with tone color/bw/duo, wipe-in, slow zoom), `hl` (condensed headline, optional box), `wide` (wide headline), `cap` (micro caption), `annot` (white bounding box with handles + label).

## 6. Motion (estimated)
Easing = fast expo-out (snappy, then settles). Lines draw in 0.7 s, staggered 0.1 s. Boxes/photos wipe 0.45-0.6 s. Headline lines slide up 0.6 s from a mask, stagger 0.12 s. Captions fade 0.5 s last. Photos drift (zoom 1 -> 1.1) while on screen. Beats: look A/B hold 3-5 s; look C changes every 0.5-1 s. Cuts and colour wipes, no cross-dissolves.

## 7. Content pattern
Reel structure: title card (look A) -> 3-4 beats, each = headline word + photo + tiny caption -> product/cutout beat on red cell (look B) -> optional detail/annotation beat (look C) -> sign-off word (e.g. "Smart." + "A story in motion."). Copy is short, poetic, 1-3 words per headline; micro-captions carry the extra line.

## 8. Audio (only level measured)
Mean / peak: ref 1 -21.7 / -3.4 dB, ref 2 -10.4 / 0 dB, ref 3 -9.5 / 0 dB. Content (music genre, sound effects) NOT analysed. Recommendation: a clean rhythmic music bed with short whoosh/tick hits on line draws and wipes; normalise to about -14 LUFS. `tools/render.py` mixes your `--voice`/`--music` files.

## 9. Visual QA (render `--sheet`, look at it)
[ ] everything sits on a grid line or cell edge [ ] one headline per beat [ ] every beat has an image [ ] captions tiny, in corners, not overlapping the headline [ ] only palette colours, only 2 typefaces [ ] lines/nodes consistent per scene [ ] contrast OK (white on red, red on white/grey) [ ] no shadows/glows [ ] spelling [ ] hard cuts/wipes only

---
name: swiss-grid-motion-style
description: Make short editorial motion-design reels in the "Swiss grid" style - visible thin grid lines with nodes, giant condensed red headlines, tiny tracked captions, photo tiles (B/W and red duotone), solid red blocks and wide-type annotation beats. Three looks (white, grey dashed, black/red). Editing only; the user supplies photos/clips and optional audio. Use for studio reels, brand intros, portfolio and mood-film reels.
---
# Swiss Grid Motion (editing only)
No voice or transcription models. Needs Python 3, `pip install playwright && playwright install chromium`, ffmpeg, fonts in `fonts/` (Anton, Montserrat, Unbounded: free Google Fonts).
**Read `docs/STYLE_BIBLE.md` (section 0 first), `docs/BEAT_SHEETS.md`, and look at `reference/*.jpg` before planning.**
## Workflow
1. **Intake (one message):** subject/brand, 3-6 words that carry the idea, photos or clips (or "use placeholders"), look A/B/C (default: A title + B beats), length (15-25 s), aspect (16:9 default), optional music.
2. **Plan (one screen, then wait):** table `beat | look | headline word | image | caption lines | seconds`. Every beat has ONE word + ONE image. Ask "Build it?".
3. **Build:** copy `template/scenes.js`, edit scenes. Elements: line, node, rect, tile (src/ph, tone color|bw|duo, zoom), hl (box optional), wide, cap, annot. Put photos in `template/img/` and use `src:"img/x.jpg"`.
4. **QA:** `python3 tools/render.py --sheet review.jpg` and LOOK at it; run the checklist in STYLE_BIBLE section 9; fix, re-render. One frame: `template/index.html?t=3.2`.
5. **Deliver:** `python3 tools/render.py --out final.mp4 [--voice a.mp3] [--music m.mp3] [--scale 1]`. Report what you fixed.
## Never
Off-grid elements; shadows, glows, new colours or fonts; paragraphs on screen; text-only beats; using other people's photos without permission; claiming a frame is fine without looking.

/* Deterministic Swiss-grid scene engine. window.seek(t) draws the exact frame at t seconds (stage 1920x1080).
   Scenes: window.PROJECT = {duration, scenes:[{bg,start,end,zoom?,els:[...]}]}  Element types: line node rect tile hl wide cap annot */
(function(){
const P=window.PROJECT,stage=document.getElementById('stage');
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const expo=p=>p>=1?1:1-Math.pow(2,-10*p), cub=p=>1-Math.pow(1-p,3), back=p=>{const c=1.5;return 1+(c+1)*Math.pow(p-1,3)+c*Math.pow(p-1,2)};
const el=(c,h,css)=>{const n=document.createElement('div');n.className=c;if(h!=null)n.innerHTML=h;if(css)Object.assign(n.style,css);return n};
const place=(n,o)=>{n.style.left=o.x+'px';n.style.top=o.y+'px';if(o.w)n.style.width=o.w+'px';if(o.h)n.style.height=o.h+'px';
  n._b=o.anchor==='c'?'translateX(-50%)':o.anchor==='r'?'translateX(-100%)':'';if(o.anchor==='c')n.style.textAlign='center';if(o.anchor==='r')n.style.textAlign='right'};
const A=(n,at,dur,anim,base)=>({n,at,dur,anim,base:base??n._b??''});
const B={
 line:(o)=>{const h=o.y2===undefined||o.y2===o.y;const n=el('ln');const w=o.w||2,L=h?(o.x2-o.x):(o.y2-o.y),c=o.color||'var(--line-red)';
   n.style.left=o.x+'px';n.style.top=o.y+'px';
   if(h){n.style.width=L+'px';n.style.height=w+'px'}else{n.style.width=w+'px';n.style.height=L+'px'}
   n.style.background=o.dash?`repeating-linear-gradient(${h?90:180}deg,${c} 0 ${o.dash}px,transparent ${o.dash}px ${o.dash*1.8}px)`:c;
   n._o=h?(o.from==='end'?'right center':o.from==='center'?'center':'left center'):(o.from==='end'?'center bottom':o.from==='center'?'center':'center top');n._h=h;
   return[{n,at:o.at,dur:o.dur||.7,anim:h?'drawX':'drawY',base:''}]},
 node:(o)=>{const s=o.size||16,n=el('nd');n.style.cssText+=`left:${o.x-s/2}px;top:${o.y-s/2}px;width:${s}px;height:${s}px;background:${o.color||'var(--red)'};border-radius:${o.shape==='square'?0:50}%`;return[A(n,o.at,.3,'pop','')]},
 rect:(o)=>{const n=el('rect');place(n,o);n.style.background=o.color||'var(--red)';return[A(n,o.at,o.dur||.5,o.anim||'wipeX',n._b)]},
 tile:(o,s)=>{const n=el('tile '+(o.tone||'color'));place(n,o);const im=el('im');if(o.src)im.style.backgroundImage=`url("${o.src}")`;else{im.style.background=o.ph||'linear-gradient(135deg,#999,#555)';im.style.backgroundSize='cover'}
   if(o.blur)im.style.filter=`grayscale(1) blur(${o.blur}px)`;n.appendChild(im);if(o.zoom)s.zooms.push({im,z:o.zoom,at:o.at});
   return[A(n,o.at,o.dur||.6,o.anim||'wipeX',n._b)]},
 hl:(o,s,wide)=>{const n=el(wide?'el wide':'el hl');place(n,o);n.style.fontSize=(o.size||160)+'px';n.style.color=o.color||'var(--red)';const it=[];
   if(o.box){n.style.background=o.box;n.style.padding=`${o.padY??14}px ${o.padX??40}px`;n.style.overflow='hidden';it.push(A(n,o.at,.45,'wipeX',n._b))}else it.push(A(n,0,.01,'none',n._b));
   String(o.text).split('|').forEach((t,i)=>{const l=el('l','<span>'+t+'</span>');n.appendChild(l);it.push({n:l.firstChild,at:o.at+(o.box?.2:0)+i*(o.stagger??.12),dur:.6,anim:'slideUp',base:''})});return it},
 wide:(o,s)=>B.hl(o,s,true),
 cap:(o)=>{const n=el('el cap',String(o.text).split('|').join('<br>'));place(n,o);n.style.color=o.color||'var(--red)';if(o.size)n.style.fontSize=o.size+'px';return[A(n,o.at,.5,o.anim||'fade',n._b)]},
 annot:(o)=>{const n=el('annot','<i></i><i></i><i></i><i></i>'+(o.label?`<b>${o.label}</b>`:''));place(n,o);return[A(n,o.at,.35,'fade','')]}
};
P.scenes.forEach(s=>{s.node=el('scene '+s.bg);s.items=[];s.zooms=[];stage.appendChild(s.node);
 (s.els||[]).forEach(o=>B[o.t](o,s).forEach(it=>{s.items.push(it)}));
 s.items.forEach(it=>{if(!it.n.parentNode)s.node.appendChild(it.n)});
 // keep z-order = element order
});
function apply(it,p){const n=it.n,b=it.base||'';let o=1,tf='',cp='';const e=expo(p);
 switch(it.anim){case'pop':o=clamp(p*5);tf=`scale(${.4+.6*back(p)})`;break;case'fade':o=cub(p);break;case'none':break;
  case'slideUp':tf=`translateY(${(1-e)*108}%)`;break;
  case'wipeX':o=p>0?1:0;cp=`inset(0 ${(1-e)*100}% 0 0)`;break;case'wipeY':o=p>0?1:0;cp=`inset(0 0 ${(1-e)*100}% 0)`;break;
  case'drawX':o=p>0?1:0;n.style.transformOrigin=n._o;tf=`scaleX(${e})`;break;case'drawY':o=p>0?1:0;n.style.transformOrigin=n._o;tf=`scaleY(${e})`;break;}
 n.style.opacity=o;n.style.transform=(b+' '+tf).trim();n.style.clipPath=cp||'none';}
window.seek=function(t){P.scenes.forEach(s=>{const on=t>=s.start&&t<s.end;s.node.style.display=on?'block':'none';if(!on)return;const lt=t-s.start,k=lt/(s.end-s.start);
  s.items.forEach(it=>apply(it,clamp((lt-it.at)/it.dur)));
  s.zooms.forEach(z=>{z.im.style.transform=`scale(${z.z[0]+(z.z[1]-z.z[0])*clamp((lt-z.at)/(s.end-s.start-z.at))})`});});};
window.PROJECT_DURATION=P.duration;seek(0);
})();

/* EXAMPLE PROJECT (16 s) showing the 3 reference looks. Replace ph gradients with your own photos via src:"img/x.jpg".
   Coordinates are px on a 1920x1080 stage. at = seconds after the scene starts. Line colour defaults to red. */
const INK='var(--red-deep)',W='#fff',DASH='rgba(200,20,28,.7)',LT='rgba(255,255,255,.5)';
window.PROJECT={duration:16,scenes:[
{bg:'white',start:0,end:3.4,els:[
 {t:'line',x:697,y:0,y2:1080,w:3,at:0,dur:.8},{t:'line',x:1221,y:0,y2:1080,w:3,at:.1,dur:.8},
 {t:'line',x:0,y:430,x2:1920,w:3,at:.2,dur:.8},{t:'line',x:0,y:626,x2:1920,w:3,at:.3,dur:.8},
 {t:'node',x:697,y:430,at:.8},{t:'node',x:1221,y:430,at:.85},{t:'node',x:697,y:626,at:.9},{t:'node',x:1221,y:626,at:.95},
 {t:'rect',x:697,y:430,w:524,h:196,at:.9,anim:'wipeX'},
 {t:'hl',text:'SMART',x:959,y:431,anchor:'c',size:170,color:W,at:1.1},
 {t:'hl',text:'CREATE.',x:686,y:328,anchor:'r',size:96,at:1.5},{t:'hl',text:'INSPIRE.',x:1232,y:328,size:96,at:1.65},
 {t:'cap',text:'THIS IS|WHERE IT|BEGINS',x:686,y:646,anchor:'r',at:2.0},{t:'cap',text:'A STORY IN|MOTION.',x:1232,y:646,at:2.1}]},
{bg:'grey',start:3.4,end:8.2,els:[
 {t:'line',x:360,y:0,y2:1080,dash:9,color:DASH,at:0},{t:'line',x:1080,y:0,y2:1080,dash:9,color:DASH,at:.1},{t:'line',x:1560,y:0,y2:1080,dash:9,color:DASH,at:.2},
 {t:'line',x:0,y:300,x2:1920,dash:9,color:DASH,at:.15},{t:'line',x:0,y:820,x2:1920,dash:9,color:DASH,at:.25},
 {t:'node',x:360,y:300,at:.5,size:12},{t:'node',x:1080,y:300,at:.55,size:12},{t:'node',x:360,y:820,at:.6,size:12},{t:'node',x:1080,y:820,at:.65,size:12},
 {t:'cap',text:'EST. 2025|MOTION / DESIGN|FRAME 01',x:60,y:50,size:22,color:INK,at:.4},
 {t:'hl',text:'THE|SMART|STUDIOS',x:1100,y:40,size:130,at:.5},
 {t:'tile',x:360,y:560,w:360,h:260,tone:'duo',ph:'linear-gradient(120deg,#e9dfd5,#8a7b72)',at:1.0},
 {t:'tile',x:720,y:360,w:360,h:460,tone:'color',ph:'linear-gradient(160deg,#f3ead8,#6b5a52)',at:1.2,zoom:[1,1.1]},
 {t:'tile',x:1080,y:560,w:240,h:260,tone:'duo',ph:'linear-gradient(120deg,#ddd,#755)',at:1.4},
 {t:'tile',x:1320,y:440,w:360,h:260,tone:'color',ph:'linear-gradient(120deg,#e0a24a,#8a4b12)',at:1.6},
 {t:'cap',text:'STUDIO REEL|VISUAL CRAFT|SIGNAL 01',x:1860,y:930,anchor:'r',size:22,color:INK,at:1.8}]},
{bg:'redd',start:8.2,end:11.6,els:[
 {t:'line',x:640,y:0,y2:1080,w:2,color:LT,at:0},{t:'line',x:1280,y:0,y2:1080,w:2,color:LT,at:.1},
 {t:'line',x:0,y:360,x2:1920,w:2,color:LT,at:.1},{t:'line',x:0,y:720,x2:1920,w:2,color:LT,at:.2},
 {t:'rect',x:640,y:360,w:640,h:360,color:'#fff',at:.4,anim:'wipeY'},
 {t:'tile',x:640,y:360,w:640,h:360,ph:'radial-gradient(ellipse 30% 40% at 50% 50%,#b9692c 0 90%,transparent 92%),#fff',at:.8,anim:'wipeY'},
 {t:'tile',x:1280,y:0,w:640,h:360,tone:'bw',ph:'linear-gradient(120deg,#ccc,#444)',at:.5,zoom:[1,1.12]},
 {t:'hl',text:'CROISSANT|STUDY',x:620,y:500,anchor:'r',size:70,color:W,at:1.0},
 {t:'cap',text:'FRESH BAKE|FRAME 03|MORNING SERIES',x:620,y:270,anchor:'r',size:20,color:W,at:1.3},
 {t:'cap',text:'TEXTURE STUDY|REC. 03|SEP 01 2026',x:1300,y:450,size:20,color:W,at:1.4}]},
{bg:'black',start:11.6,end:16,els:[
 {t:'rect',x:0,y:0,w:1920,h:1080,color:'var(--red-hot)',at:0,anim:'wipeY',dur:.6},
 {t:'line',x:0,y:380,x2:1920,w:2,dash:8,color:LT,at:.4},{t:'line',x:0,y:700,x2:1920,w:2,dash:8,color:LT,at:.5},
 {t:'tile',x:480,y:420,w:240,h:260,ph:'linear-gradient(135deg,#5a7a2a,#2a1a0a)',at:.8,anim:'wipeY'},
 {t:'tile',x:740,y:420,w:240,h:260,ph:'linear-gradient(135deg,#a8142b,#3a0610)',at:.9,anim:'wipeY'},
 {t:'tile',x:1000,y:420,w:240,h:260,ph:'linear-gradient(135deg,#d99a2a,#4a1c0a)',at:1.0,anim:'wipeY'},
 {t:'tile',x:1260,y:420,w:240,h:260,ph:'linear-gradient(135deg,#8ab53a,#1c2a0a)',at:1.1,anim:'wipeY'},
 {t:'annot',x:740,y:420,w:240,h:260,label:'Stigma',at:1.5},{t:'annot',x:1260,y:420,w:240,h:260,label:'Receptacle',at:1.65},
 {t:'rect',x:0,y:0,w:1920,h:1080,color:'#000',at:2.4,anim:'wipeX',dur:.5},
 {t:'wide',text:'LIVING|STUDIES',x:960,y:300,anchor:'c',size:170,color:W,at:3.0},
 {t:'tile',x:760,y:330,w:400,h:420,ph:'linear-gradient(135deg,#d62a3a,#2a0a10)',at:3.2,anim:'wipeY'},
 {t:'annot',x:760,y:330,w:400,h:420,label:'Surface_01',at:3.6}]}
]};

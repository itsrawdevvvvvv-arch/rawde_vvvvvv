# Swiss Grid Motion Style (editing-only pack)
Reproduces the editing style of your 3 reference clips: visible grid lines + nodes, giant condensed red headlines, tiny captions, photo tiles in B/W / red duotone, red blocks, wide-type annotation beats. Everything is presented visually.
- `SKILL.md` give this folder to any AI. `docs/STYLE_BIBLE.md` full rules. `docs/BEAT_SHEETS.md` reference timelines.
- `style/`, `engine/` design tokens and scene player. `template/scenes.js` working 16 s example showing all 3 looks.
- `tools/render.py` render to MP4 or contact sheet. `reference/` your frames + `rebuild_proof_sheet.jpg`.
Setup: Python 3, playwright (+chromium), ffmpeg, fonts in `fonts/`.
Limits: motion timing and fonts are estimates; audio content not analysed; the proof sheet used a fallback font (Anton was not installed where it was built), so real headlines will be narrower and bolder.

/* raw-helpers.js - bundled inside kinetic-explainer-style.zip for offline Local Asset Locker + Video Sync */
(function(global) {
  function normPath(p) {
    return String(p || "").replace(/^\.?\//, "");
  }

  function syncVideoImpl(videoEl, t, start, end, speed) {
    if (!videoEl) return Promise.resolve();
    var s = Number.isFinite(start) ? start : 0;
    var e = (end == null || !Number.isFinite(end)) ? Infinity : end;
    var sp = (speed == null || !Number.isFinite(speed) || speed <= 0) ? 1 : speed;

    videoEl.muted = true;
    videoEl.playsInline = true;
    videoEl.preload = "auto";
    if (!videoEl.paused) {
      try { videoEl.pause(); } catch (_) {}
    }

    function computeTarget() {
      var dur = (Number.isFinite(videoEl.duration) && videoEl.duration > 0) ? videoEl.duration : 60;
      var clampedGlobal = Math.max(s, Math.min(t, e));
      var localT = Math.max(0, (clampedGlobal - s) * sp);
      return Math.min(localT, Math.max(0, dur - 0.033));
    }

    function performSeek() {
      var target = computeTarget();
      if (Math.abs((videoEl.currentTime || 0) - target) < 0.015 && videoEl.readyState >= 2) {
        return Promise.resolve();
      }
      return new Promise(function(resolve) {
        var done = false;
        var timer = setTimeout(finish, 240);
        function finish() {
          if (done) return;
          done = true;
          clearTimeout(timer);
          videoEl.removeEventListener("seeked", finish);
          videoEl.removeEventListener("canplay", onCanPlay);
          resolve();
        }
        function onCanPlay() {
          if (videoEl.readyState >= 2 && Math.abs((videoEl.currentTime || 0) - target) < 0.02) {
            finish();
          }
        }
        videoEl.addEventListener("seeked", finish, { once: true });
        videoEl.addEventListener("canplay", onCanPlay);
        try {
          videoEl.currentTime = target;
        } catch (_) {
          finish();
        }
      });
    }

    var p;
    if (videoEl.readyState < 1) {
      p = new Promise(function(resolve) {
        var settled = false;
        var metaTimer = setTimeout(go, 320);
        function go() {
          if (settled) return;
          settled = true;
          clearTimeout(metaTimer);
          videoEl.removeEventListener("loadedmetadata", go);
          videoEl.removeEventListener("error", go);
          performSeek().then(resolve);
        }
        videoEl.addEventListener("loadedmetadata", go, { once: true });
        videoEl.addEventListener("error", go, { once: true });
      });
    } else {
      p = performSeek();
    }

    videoEl.__rawSeekPromise = p;
    return p;
  }

  function attachHelpers(obj) {
    if (!obj || typeof obj !== "object") return obj;
    if (typeof obj.syncVideo !== "function") obj.syncVideo = syncVideoImpl;
    if (!obj.assets) obj.assets = global.__RAW_ASSETS__ || {};
    if (typeof obj.asset !== "function") {
      obj.asset = function(path) {
        var key = normPath(path);
        return (obj.assets && obj.assets[key]) || key;
      };
    }
    return obj;
  }

  global.__rawSyncVideo = syncVideoImpl;
  var store = attachHelpers(global.RAW || {});
  try {
    Object.defineProperty(global, "RAW", {
      configurable: true,
      enumerable: true,
      get: function() { return store; },
      set: function(next) {
        if (next && typeof next === "object") {
          store = attachHelpers(next);
        }
      }
    });
  } catch (_) {
    global.RAW = store;
  }
})(window);

# Local Asset Locker & Video Sync Guide (`assets/` + `RAW.syncVideo`)

The `raw_edit` Android app intercepts relative `assets/...` URLs completely offline using a sandboxed local asset server (including HTTP byte-Range requests for crisp `<video>` frame scrubbing).

## 1. Referencing Attached Images, PNG Cutouts & Video Clips
- Always use relative paths exactly as listed in the prompt (e.g. `<img src="assets/cutout_1.png">` or `<video src="assets/demo_clip.mp4" muted playsinline preload="auto"></video>`).
- **Never** invent external `http://` or `https://` URLs or huge inline data URIs for user clips.
- Respect each asset's AI-inspected visual description and **safe text zone** so kinetic titles never cover the focal subject or collide with foreground UI.
- Keep `<img>` and `<video>` positioned inside the `1920x1080` safe grid (`80px-120px` outer margin, `object-fit: cover` or `contain`).

## 2. Deterministic `<video>` Scrubbing with `RAW.syncVideo`
Because offline rendering jumps cleanly to arbitrary timestamps `t` (during both Keyframe Contact Sheet sampling and MP4 frame encoding), `<video>` elements MUST NOT rely on `.play()`, `requestAnimationFrame`, or `setInterval`.

Instead, call `RAW.syncVideo(videoEl, t, start, end, speed)` inside `window.RAW.seek(t)`:
- `videoEl`: your `<video>` DOM element (`muted`, `playsinline`, `preload="auto"`).
- `t`: current global timeline timestamp in seconds.
- `start` *(optional, default `0`)*: global timeline timestamp when this scene begins.
- `end` *(optional, default `Infinity`)*: global timeline timestamp when this scene ends.
- `speed` *(optional, default `1`)*: playback speed multiplier (`1.5`, `2.0`, etc.).

Example inside `window.RAW`:
```js
const clip = document.getElementById("demoClip");
window.RAW = {
  duration: 14.0,
  width: 1920,
  height: 1080,
  fps: 30,
  seek(t) {
    // 1. Update scenes & kinetic typography transforms for t...
    // 2. Sync <video> between scene t=4.0s and t=9.5s at 1.25x speed:
    if (clip && t >= 4.0 && t <= 9.5) {
      return RAW.syncVideo(clip, t, 4.0, 9.5, 1.25);
    }
  }
};
```
`RAW.syncVideo` is bundled here in `engine/raw-helpers.js` AND automatically injected at runtime by `raw_edit`, even when outputting a single self-contained HTML file.

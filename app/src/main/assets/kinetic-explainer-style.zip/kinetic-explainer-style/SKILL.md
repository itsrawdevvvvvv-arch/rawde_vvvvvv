---
name: kinetic-explainer-style
description: Make short (40-60 s) 16:9 kinetic-typography explainers in the "cream and crimson" (or custom Palette PNG) style - giant headlines, icon cards with viewfinder brackets, phone mockups, chips, counters, local Asset Locker media, follow/comment CTAs - where every spoken idea is shown visually. Editing only; the user supplies the voiceover audio and optional local assets.
---
# Kinetic Explainer Style (editing only)
You build the video from the user's script and voiceover audio. No voice generation, no transcription, no model downloads.
Needs: Node-free. Python 3, `pip install playwright && playwright install chromium`, ffmpeg, Poppins TTFs in `fonts/` (or bundled OFL fonts inside `raw_edit` Android app).
**Read `docs/STYLE_BIBLE.md` first (especially section 0), then `docs/BEAT_SHEETS.md`, and `docs/ASSETS_GUIDE.md` if using local `assets/`. Look at `reference/*.jpg`.**

## Workflow
1. **Intake (one message)**: topic, script text, voiceover file (and scene start times, or say "I'll listen and time it"), language, palette, optional `assets/` list, handle/CTA keyword.
2. **Plan (one screen, then wait)**: a table `narration line | scene type + bg colour | visual object(s) on screen | start s`. Every line MUST have a visual object (Prime Directive). Check colour rhythm. Ask "Build it?".
3. **Build**: copy `template/scenes.js` (or emit one single-file HTML for `raw_edit`), use `engine/raw-helpers.js` when embedding `<video>` clips via `RAW.syncVideo(videoEl, t, start, end, speed)` and local `assets/...` images/cutouts.
4. **QA**: inspect keyframe sheet / contact sheet carefully; run the checklist in STYLE_BIBLE section 9 and `docs/ASSETS_GUIDE.md`. Fix and re-render. Single frame preview: open `template/index.html?t=12.5`.
5. **Deliver**: single-file HTML defining `window.RAW = { duration, width: 1920, height: 1080, seek(t) }` or `python3 tools/render.py --out final.mp4 --voice voice.mp3 [--music bed.mp3]`. Report what you caught and fixed.

## Never
Plain text-only scenes; external `http(s)://` URLs in offline HTML; copying another creator's script or screenshots; claiming a frame is fine without checking safe zones and overflow; playing `<video>` without `RAW.syncVideo(videoEl, t, start, end, speed)`.
